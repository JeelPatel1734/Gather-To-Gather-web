export default {
  primary: '#6200ee',
  secondary: '#03dac6',
  background: '#f5f5f5',
  text: '#000000',
  white: '#ffffff',
  gray: '#808080',
};
