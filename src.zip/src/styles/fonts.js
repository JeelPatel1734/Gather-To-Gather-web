export default {
  regular: 'Roboto-Regular',
  bold: 'Roboto-Bold',
  sizeSmall: 12,
  sizeMedium: 16,
  sizeLarge: 20,
};
