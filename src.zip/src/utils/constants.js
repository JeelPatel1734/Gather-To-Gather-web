export const APP_NAME = 'Gather-to-Gather';
export const API_ENDPOINT = 'https://api.example.com';
